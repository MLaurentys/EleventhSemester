export const API_DATA = {
  API_KEY: 'd71bea95cdca3d4c0002aa72148c6e16',
  API_URL: 'https://api.themoviedb.org/3/',
};
