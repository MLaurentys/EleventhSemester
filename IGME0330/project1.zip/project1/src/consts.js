export const API_ENDPOINT = "https://api.themoviedb.org/3/";
export const IMAGES_ENDPOINT = "https://image.tmdb.org/t/p/original";
